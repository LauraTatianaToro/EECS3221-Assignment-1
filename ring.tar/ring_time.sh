#!/bin/bash

for ((i = 10 ; i <= 10000 ; i=i*10)); do
  ./ring 20 0 $i >> timing.out
done


