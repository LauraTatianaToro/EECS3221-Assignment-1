


/* Signal ring */
/* Ring takes 3 parameters: n, leader(must be 0) and cnt. 
Ring creates a ring of n proccesses using fork-exec. Once n=1 proccess is reached,
it sends a SIGUSR1 to the original parent(leader). The original parent then sends SIGUSR1 to
it's child, who send its to it's child, etc... until it reaches n=1 agian, which sends
a signal to the original parent. This loops cnt times. The end displays cnt and 
total elapsed time.

Student Name: Laura Toro
ID: 216650236
Date June 9th 2021*/

#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>

//declaring global variables
pid_t pid;
int N;
int leader;
int cnt;
int tempcnt = 0;
time_t begin, end;


void handle_sigusr1(int sig){
  //handles SIGUSR1

  //printf("%d received sig\n", getpid());
  //if n!=1 send SIGUSR to child process
    if(N != 1){
        kill(pid, SIGUSR1);
    } else if( N == 1){
        //printf("one loop\n");
        //if n==1, send leader SIGUSR1 & increment cnt
        kill(leader, SIGUSR1);
       if(tempcnt == cnt){
         kill(-1, SIGTERM);
       }
    }
}


int main(int argc, char ** argv){

    //begin timer
    begin = time(NULL);


    //redefining signal handler for each new process
    sigset_t sset;
    //filling the set with SIGUSR1
    sigfillset(&sset);
    sigdelset(&sset, SIGUSR1);
    //declaring signal handler
    struct sigaction sa;
    sa.sa_flags = SA_RESTART;
    sa.sa_handler = &handle_sigusr1;
    sigaction(SIGUSR1, &sa, NULL);

    //convert argv from string to int
    N = atoi(argv[1]);
    leader = atoi(argv[2]);
    cnt = atoi(argv[3]);

    //setting leader to original process id 
    if (leader == 0){ 
        leader = getpid(); 
    } 

    //creating child
    pid = fork();
    if(pid < 0 ){ 
        return 1; 
    }

    if (pid == 0){
      //child process

      //base case
      if (N == 1){
          //printf("Hello from N=1 with pid: %d\n", getpid());
          kill(leader, SIGUSR1);  
      } else {

          //printf("Child with ID %d has variables: N: %d, leader: %d, and cnt: %d\n", getpid(), N, leader, cnt);
          //printf("Child with ID %d has parent ID %d \n", getpid(), getppid());

          //decrement N
          N = N-1; 

          //convert ints to strings to pass through exec
          char str1[12];
          sprintf(str1, "%d", N);
          char str2[12];
          sprintf(str2, "%d", leader);
          char str3[12];
          sprintf(str3, "%d", cnt);  
          
          //declaring an array to pass through exec
          char* args[] = {"./ring", str1, str2, str3, NULL};

          //calling exec
          execv(args[0], args);
      }
      
    } else {
      //parent processes
      
      //printf("Parent with ID %d variables: N : %d, leader: %d, and cnt: %d\n", getpid(), N, leader, cnt);

      for(int x = 0; x < cnt; x++){
          sigsuspend(&sset);
          tempcnt++;
          //printf("cnt is %d\n", tempcnt);
      }

      wait(NULL);

      //end timer
      

      if(getpid()==leader && (tempcnt == cnt)){
          end = time(NULL);
          printf("cnt = %d, total time elapsed: %lf seconds\n", tempcnt, (double)(end - begin));
      }
    }
        
      return 0;
}
